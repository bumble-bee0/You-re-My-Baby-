
## Update 1.2.0
- Fixed remote tap coordinate mapping when the live screen is scaled with `FIT_CENTER`.
- Added normalized remote swipe gestures from the Parent live-screen view.
- Improved Android 14+ photo permission handling for full or selected-photo access.
- Fixed time-limit resume so restarting the foreground service does not reset/extend the original deadline.
- Cleans up the pairing-service listener when the service is destroyed.
- Relay server now replaces stale duplicate connections for the same role/code.

# 🧸 You're My Baby

A small family parental-control MVP with **Parent Mode** and a game-like **Baby Mode**.

## What is included
- 6-digit pairing
- Persistent role/pairing setup in app storage
- Parent dashboard
- Remote screen MVP using Android MediaProjection
- Remote Home / Back / Recents / tap via Accessibility Service
- Request latest photos after photo permission is granted
- Foreground connection service for the pairing socket
- Friendly Baby Mode UI
- Baby-bear launcher icon
- GitHub Actions workflow that builds a debug APK without requiring a committed Gradle wrapper
- Node.js WebSocket relay server

## Important Android limitation
The app never bypasses Android privacy controls. Screen capture uses MediaProjection and must follow the consent rules of the Android version running on the Baby device. Camera/microphone are not implemented as hidden background monitoring.

## GitHub → APK
1. Create an empty GitHub repository.
2. Extract this ZIP and upload the **contents** (so `.github`, `app`, `server`, `build.gradle`, etc. are at repository root).
3. Open **Actions → Build APK → Run workflow**.
4. After it finishes, open the workflow run and download the artifact named `youre-my-baby-debug-apk`.

## Pairing server
GitHub Pages cannot run a WebSocket server. Deploy `server/` to a Node/WebSocket host first. A `render.yaml` is included as a deployment template.

Then open the app → **Pengaturan** → enter the deployed `wss://...` address. Use the same server address on both Parent and Baby devices.

## Android Studio
Open the repository root in Android Studio. The project uses Android Gradle Plugin 8.7.3, compile/target SDK 35, min SDK 26. GitHub Actions installs Gradle 8.10.2 and Android SDK 35 automatically, so the repository does not depend on a locally committed Gradle wrapper.

## Privacy
This project is designed for devices you are authorized to manage. It does not include stealth camera/microphone capture, permission bypasses, or hidden screen recording.

## Current implementation status (v1.2.0)
- Native Parent/Baby UI updated toward the supplied 11-screen mockup.
- Parent receives binary screen frames and displays them in Layar Langsung.
- Live-screen tap coordinates are normalized against the actual displayed bitmap and swipe gestures are supported.
- Photo permission supports Android 14+ full/selected media permission checks.
- Time limits persist their configured duration/deadline in SharedPreferences and are enforced by the child foreground service when Accessibility is enabled.
- Riwayat & Lokasi is intentionally shown as unavailable; no fake location/history is generated.
- All 11 supplied screen references are included under `design-reference/` and are the authoritative visual references for native UI polishing.
- Fixed hard-coded pixel sizing in the native UI helpers so spacing and component sizes scale correctly across Android screen densities.
- No covert camera/microphone capture or permission bypass is implemented.
