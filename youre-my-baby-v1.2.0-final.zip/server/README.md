# You're My Baby Relay

WebSocket relay sederhana untuk meneruskan pesan antara Parent Mode dan Baby Mode.

## Deploy

Folder ini bisa dideploy ke Render/hosting Node.js yang mendukung WebSocket.

Environment:
- `PORT` disediakan otomatis oleh platform.

Setelah deploy, gunakan URL WebSocket hasil deploy pada menu **Pengaturan → Server** di aplikasi, misalnya `wss://nama-service.onrender.com`.
