const http = require('http');
const WebSocket = require('ws');
const port = process.env.PORT || 8080;
const server = http.createServer((req,res)=>{res.writeHead(200,{'content-type':'text/plain'});res.end("You're My Baby relay is running\n");});
const wss = new WebSocket.Server({server});
const sessions = new Map();
function send(ws,obj){ if(ws && ws.readyState===WebSocket.OPEN) ws.send(JSON.stringify(obj)); }
wss.on('connection',(ws)=>{
  ws.meta={role:null,code:null};
  ws.on('message',(data,isBinary)=>{
    if(!ws.meta.role){
      if(isBinary) return;
      try{
        const m=JSON.parse(data.toString());
        if(m.type!=='pair' || !/^\d{6}$/.test(m.code) || !['parent','child'].includes(m.role)) return ws.close(1008,'invalid pairing');
        ws.meta={role:m.role,code:m.code,deviceName:m.deviceName||m.role};
        let s=sessions.get(m.code); if(!s){s={};sessions.set(m.code,s);}
        const old=s[m.role];
        if(old && old!==ws && old.readyState===WebSocket.OPEN) old.close(1000,'replaced by newer connection');
        s[m.role]=ws;
        const peer=s[m.role==='parent'?'child':'parent'];
        if(peer){send(ws,{type:'paired',peerName:peer.meta.deviceName});send(peer,{type:'paired',peerName:ws.meta.deviceName});}
      }catch(e){ws.close(1008,'bad pair');}
      return;
    }
    const s=sessions.get(ws.meta.code); if(!s)return;
    const peer=s[ws.meta.role==='parent'?'child':'parent']; if(!peer||peer.readyState!==WebSocket.OPEN)return;
    if(isBinary) peer.send(data,{binary:true}); else peer.send(data.toString());
  });
  ws.on('close',()=>{const s=sessions.get(ws.meta.code);if(!s)return;if(s[ws.meta.role]===ws)delete s[ws.meta.role];if(!s.parent&&!s.child)sessions.delete(ws.meta.code);});
});
server.listen(port,()=>console.log(`YMB relay listening on ${port}`));
