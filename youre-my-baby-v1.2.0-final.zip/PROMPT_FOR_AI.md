# Prompt untuk melanjutkan project

Saya sedang mengembangkan aplikasi Android bernama **You're My Baby**. Project ini memiliki dua mode: **Parent Mode** dan **Baby Mode**.

Baby Mode harus terasa seperti game/lobby anak: sederhana, playful, banyak ilustrasi/mascot baby bear, dan tidak memakai istilah teknis yang sulit dipahami anak.

## Fitur
- Pairing dengan kode 6 digit.
- Parent dapat melihat status Baby.
- Remote screen dengan MediaProjection, tetap mengikuti permission/consent Android.
- Remote Home, Back, Recents, dan tap menggunakan Accessibility Service setelah pengguna mengaktifkannya.
- Parent dapat meminta foto terbaru setelah akses foto diberikan.
- Pairing connection dijaga oleh foreground service.
- Pengaturan untuk mengganti relay WebSocket dan menghapus pairing.

## UX Baby Mode
Gunakan bahasa seperti game, misalnya “Siap main?”, “Nyalakan Layar”, “Aktifkan Kontrol”, dan “Foto”. Hindari istilah seperti MediaProjection atau Accessibility Service di UI utama. Semua permission yang bisa dipertahankan cukup diminta pada setup; jangan membuat pengguna mengulang pairing.

## Batas keamanan Android
Jangan bypass permission Android. Jangan membuat screen capture, kamera, atau mikrofon tersembunyi. Jika versi Android mewajibkan consent baru untuk screen capture, ikuti aturan tersebut.

## Target
Project harus tetap build lewat GitHub Actions dan bisa dibuka di Android Studio. Jangan mengganti nama aplikasi dari **You're My Baby** dan jangan mengubah **Baby Mode** kembali menjadi Child Mode.
