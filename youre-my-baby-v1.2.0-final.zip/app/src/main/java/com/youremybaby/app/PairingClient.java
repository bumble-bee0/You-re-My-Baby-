package com.youremybaby.app;

import org.json.JSONObject;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import okhttp3.*;
import okio.ByteString;

public final class PairingClient {
    public interface Listener { void onMessage(String text); void onBinary(byte[] data); void onState(String state); }
    private static PairingClient instance;
    private final OkHttpClient client = new OkHttpClient.Builder().retryOnConnectionFailure(true).build();
    private final List<Listener> listeners = new CopyOnWriteArrayList<>();
    private WebSocket socket;
    private String role, code, deviceName, url;

    public static synchronized PairingClient get() { if (instance == null) instance = new PairingClient(); return instance; }
    public synchronized void addListener(Listener l) { if (l != null && !listeners.contains(l)) listeners.add(l); }
    public synchronized void removeListener(Listener l) { listeners.remove(l); }
    public synchronized void connect(String serverUrl, String role, String code, String deviceName, Listener l) {
        if (l != null) addListener(l);
        this.role=role; this.code=code; this.deviceName=deviceName; this.url=serverUrl;
        if (socket != null) socket.cancel();
        if (serverUrl == null || serverUrl.trim().isEmpty()) { notifyState("Server belum diatur"); return; }
        Request req = new Request.Builder().url(serverUrl).build();
        socket = client.newWebSocket(req, new WebSocketListener() {
            @Override public void onOpen(WebSocket ws, Response response) {
                try { JSONObject o=new JSONObject(); o.put("type","pair"); o.put("role",role); o.put("code",code); o.put("deviceName",deviceName); ws.send(o.toString()); }
                catch(Exception ignored){}
                notifyState("Terhubung ke server");
            }
            @Override public void onMessage(WebSocket ws, String text) { for(Listener x:listeners)x.onMessage(text); }
            @Override public void onMessage(WebSocket ws, ByteString bytes) { for(Listener x:listeners)x.onBinary(bytes.toByteArray()); }
            @Override public void onFailure(WebSocket ws, Throwable t, Response r) { notifyState("Koneksi terputus: "+(t.getMessage()==null?"error":t.getMessage())); }
            @Override public void onClosed(WebSocket ws, int c, String reason) { notifyState("Koneksi ditutup"); }
        });
    }
    private void notifyState(String s){ for(Listener x:listeners)x.onState(s); }
    public boolean sendJson(JSONObject o) { return socket != null && socket.send(o.toString()); }
    public boolean sendBinary(byte[] data) { return socket != null && socket.send(ByteString.of(data)); }
    public void close(){ if(socket!=null) socket.close(1000,"bye"); }
    public String getRole(){return role;} public String getCode(){return code;}
}
