package com.youremybaby.app;

import android.app.*; import android.content.*; import android.media.projection.MediaProjection; import android.media.projection.MediaProjectionManager; import android.graphics.*; import android.hardware.display.*; import android.media.*; import android.os.*; import androidx.core.app.NotificationCompat; import java.io.ByteArrayOutputStream; import org.json.JSONObject;

public class ScreenCaptureService extends Service implements PairingClient.Listener {
    private static ScreenCaptureService current;
    private MediaProjection projection; private ImageReader reader; private VirtualDisplay display; private Handler handler; private boolean streaming; private final MediaProjection.Callback projectionCallback = new MediaProjection.Callback(){ @Override public void onStop(){ stopStreaming(); } };
    @Override public void onCreate(){ super.onCreate(); current=this; PairingClient.get().addListener(this); }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        createNotification(); handler=new Handler(Looper.getMainLooper());
        if(intent!=null && intent.hasExtra("resultCode")) startCapture(intent.getIntExtra("resultCode",0),(Intent)intent.getParcelableExtra("data"));
        return START_STICKY;
    }
    private void createNotification(){ String ch="ymb_screen"; NotificationManager nm=getSystemService(NotificationManager.class); if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(ch,"Screen sharing",NotificationManager.IMPORTANCE_LOW)); Notification n=new NotificationCompat.Builder(this,ch).setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("You're My Baby").setContentText("Remote screen sharing is active").setOngoing(true).build(); startForeground(9,n); }
    private void startCapture(int resultCode,Intent data){
        if(streaming || data==null) return; MediaProjectionManagerHolder h=new MediaProjectionManagerHolder(this); projection=h.get(resultCode,data);
        if(projection==null) return;
        projection.registerCallback(projectionCallback, handler);
        android.util.DisplayMetrics dm=getResources().getDisplayMetrics(); int w=Math.min(720,dm.widthPixels); int hh=(int)(w*((float)dm.heightPixels/dm.widthPixels));
        reader=ImageReader.newInstance(w,hh,PixelFormat.RGBA_8888,2); display=projection.createVirtualDisplay("YMB",w,hh,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,null); streaming=true;
        handler.post(frameLoop);
    }
    private final Runnable frameLoop=()->{ if(!streaming||reader==null||handler==null)return; Image im=null; Bitmap raw=null; Bitmap cropped=null; try{ im=reader.acquireLatestImage(); if(im!=null){ Image.Plane p=im.getPlanes()[0]; int width=im.getWidth(),height=im.getHeight(); int row=p.getRowStride(),pixel=p.getPixelStride(); int pad=Math.max(0,row-pixel*width); raw=Bitmap.createBitmap(width+pad/pixel,height,Bitmap.Config.ARGB_8888); raw.copyPixelsFromBuffer(p.getBuffer()); cropped=pad>0?Bitmap.createBitmap(raw,0,0,width,height):raw; if(cropped!=raw)raw.recycle(); ByteArrayOutputStream out=new ByteArrayOutputStream(64*1024); cropped.compress(Bitmap.CompressFormat.JPEG,55,out); PairingClient.get().sendBinary(out.toByteArray()); } }catch(Exception ignored){} finally{if(im!=null)im.close();if(cropped!=null)cropped.recycle();else if(raw!=null)raw.recycle();if(streaming&&handler!=null)handler.postDelayed(this.frameLoop,900);} };
    public static void startFromStoredConsent(Context c){
        if(AppState.projectionData==null) return;
        Intent i=new Intent(c,ScreenCaptureService.class); i.putExtra("resultCode",AppState.projectionResult); i.putExtra("data",AppState.projectionData);
        androidx.core.content.ContextCompat.startForegroundService(c,i);
    }
    public static boolean isRunning(){ return current!=null && current.streaming; }
    public static void stopCurrent(){ if(current!=null) current.stopStreaming(); }
    public void stopStreaming(){ streaming=false; if(handler!=null)handler.removeCallbacks(frameLoop); if(display!=null)display.release(); if(reader!=null)reader.close(); if(projection!=null){ try{projection.unregisterCallback(projectionCallback);}catch(Exception ignored){} projection.stop(); projection=null; } stopSelf(); }
    @Override public void onMessage(String text){ try{JSONObject o=new JSONObject(text); if("command".equals(o.optString("type"))){ String c=o.optString("command"); if("screen_stop".equals(c))stopStreaming(); else if(RemoteAccessibilityService.instance!=null)RemoteAccessibilityService.instance.handleCommand(o); }}catch(Exception ignored){} }
    @Override public void onBinary(byte[] d){} @Override public void onState(String s){}
    @Override public void onDestroy(){ stopStreaming(); PairingClient.get().removeListener(this); current=null; super.onDestroy(); }
    @Override public IBinder onBind(Intent i){return null;}
    static class MediaProjectionManagerHolder{ private final Context c; MediaProjectionManagerHolder(Context c){this.c=c;} MediaProjection get(int rc,Intent d){ return ((MediaProjectionManager)c.getSystemService(Context.MEDIA_PROJECTION_SERVICE)).getMediaProjection(rc,d); } }
}
