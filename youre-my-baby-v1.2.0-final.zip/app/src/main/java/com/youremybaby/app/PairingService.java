package com.youremybaby.app;

import android.app.*;
import android.content.*;
import android.os.*;
import android.provider.MediaStore;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.ByteArrayOutputStream;
import androidx.core.app.NotificationCompat;
import org.json.JSONObject;

/** Keeps the parent/child WebSocket alive while the app UI is not open. */
public class PairingService extends Service implements PairingClient.Listener {
    private static final String CHANNEL = "ymb_connection";
    @Override public void onCreate(){ super.onCreate(); createNotification(); }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        String role=getSharedPreferences("ymb",MODE_PRIVATE).getString("role","");
        String code=getSharedPreferences("ymb",MODE_PRIVATE).getString("pair_code","");
        if(!role.isEmpty()&&!code.isEmpty()) PairingClient.get().connect(ServerConfig.get(this),role,code,Build.MODEL,this);
        if("child".equals(role)) resumeTimeLimitIfAny();
        return START_STICKY;
    }
    private void resumeTimeLimitIfAny(){
        int minutes=getSharedPreferences("ymb",MODE_PRIVATE).getInt("time_limit_minutes",0);
        long setAt=getSharedPreferences("ymb",MODE_PRIVATE).getLong("time_limit_set_at",0);
        if(minutes<=0||setAt<=0) return;
        long remaining=(setAt+minutes*60_000L)-System.currentTimeMillis();
        if(remaining>0) scheduleTimeLimit(remaining);
        else {
            getSharedPreferences("ymb",MODE_PRIVATE).edit().putInt("time_limit_minutes",0).putLong("time_limit_set_at",0).apply();
            if(RemoteAccessibilityService.instance!=null) RemoteAccessibilityService.instance.lockNow();
        }
    }
    private void createNotification(){
        NotificationManager nm=getSystemService(NotificationManager.class);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Koneksi You're My Baby",NotificationManager.IMPORTANCE_LOW));
        Notification n=new NotificationCompat.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.ic_menu_info_details).setContentTitle("You're My Baby").setContentText("Perangkat tetap terhubung").setOngoing(true).build();
        startForeground(8,n);
    }
    @Override public void onMessage(String text){
        try{
            JSONObject o=new JSONObject(text);
            if("command".equals(o.optString("type"))){
                String c=o.optString("command");
                if("screen_start".equals(c) && "child".equals(AppState.role)) ScreenCaptureService.startFromStoredConsent(this);
                else if("request_photos".equals(c) && "child".equals(AppState.role)) sendLatestPhotos();
                else if("set_time_limit".equals(c) && "child".equals(AppState.role)) setTimeLimit(o.optInt("minutes",0));
                else if("child".equals(AppState.role) && RemoteAccessibilityService.instance!=null) RemoteAccessibilityService.instance.handleCommand(o);
                else broadcastCommand(text);
            }
        }catch(Exception ignored){}
    }
    private final Handler timeLimitHandler=new Handler(Looper.getMainLooper());
    private Runnable timeLimitRunnable;
    private void setTimeLimit(int minutes){
        if(minutes<=0){
            if(timeLimitRunnable!=null) timeLimitHandler.removeCallbacks(timeLimitRunnable);
            getSharedPreferences("ymb",MODE_PRIVATE).edit().putInt("time_limit_minutes",0).putLong("time_limit_set_at",0).apply();
            return;
        }
        getSharedPreferences("ymb",MODE_PRIVATE).edit().putInt("time_limit_minutes",minutes).putLong("time_limit_set_at",System.currentTimeMillis()).apply();
        scheduleTimeLimit(minutes*60_000L);
    }
    private void scheduleTimeLimit(long delayMs){
        if(timeLimitRunnable!=null) timeLimitHandler.removeCallbacks(timeLimitRunnable);
        timeLimitRunnable=()->{
            getSharedPreferences("ymb",MODE_PRIVATE).edit().putInt("time_limit_minutes",0).putLong("time_limit_set_at",0).apply();
            if(RemoteAccessibilityService.instance!=null) RemoteAccessibilityService.instance.lockNow();
            try{broadcastCommand(new JSONObject().put("type","time_limit_reached").toString());}catch(Exception ignored){}
            try{PairingClient.get().sendJson(new JSONObject().put("type","time_limit_reached"));}catch(Exception ignored){}
        };
        timeLimitHandler.postDelayed(timeLimitRunnable,Math.max(1,delayMs));
    }
    private void broadcastCommand(String text){ sendBroadcast(new Intent("com.youremybaby.COMMAND").putExtra("json",text).setPackage(getPackageName())); }
    private void sendLatestPhotos(){
        try {
            boolean photoAllowed;
            if(Build.VERSION.SDK_INT>=34){
                photoAllowed=checkSelfPermission(android.Manifest.permission.READ_MEDIA_IMAGES)==android.content.pm.PackageManager.PERMISSION_GRANTED
                        || checkSelfPermission(android.Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)==android.content.pm.PackageManager.PERMISSION_GRANTED;
            } else if(Build.VERSION.SDK_INT>=33){
                photoAllowed=checkSelfPermission(android.Manifest.permission.READ_MEDIA_IMAGES)==android.content.pm.PackageManager.PERMISSION_GRANTED;
            } else {
                photoAllowed=checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)==android.content.pm.PackageManager.PERMISSION_GRANTED;
            }
            if (!photoAllowed) {
                broadcastCommand(new JSONObject().put("type","photos_unavailable").put("reason","photo_permission_missing").toString());
                return;
            }
            android.database.Cursor cur=getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    new String[]{MediaStore.Images.Media._ID,MediaStore.Images.Media.DISPLAY_NAME,MediaStore.Images.Media.DATE_ADDED},null,null,MediaStore.Images.Media.DATE_ADDED+" DESC");
            if(cur==null)return;
            JSONObject out=new JSONObject(); out.put("type","photos"); org.json.JSONArray arr=new org.json.JSONArray(); int n=0;
            java.text.SimpleDateFormat fmt=new java.text.SimpleDateFormat("HH:mm",java.util.Locale.US);
            while(cur.moveToNext()&&n<6){
                long id=cur.getLong(0);
                long dateAddedSec=cur.getLong(2);
                Bitmap b=MediaStore.Images.Thumbnails.getThumbnail(getContentResolver(),id,MediaStore.Images.Thumbnails.MINI_KIND,null);
                if(b==null)continue;
                ByteArrayOutputStream bytes=new ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG,55,bytes);
                JSONObject item=new JSONObject(); item.put("name",cur.getString(1)); item.put("time",fmt.format(new java.util.Date(dateAddedSec*1000))); item.put("data",android.util.Base64.encodeToString(bytes.toByteArray(),android.util.Base64.NO_WRAP)); arr.put(item);
                b.recycle(); n++;
            }
            cur.close(); out.put("items",arr); PairingClient.get().sendJson(out);
        } catch(Exception e){ try{broadcastCommand(new JSONObject().put("type","photos_unavailable").put("reason","error").toString());}catch(Exception ignored){} }
    }
    @Override public void onBinary(byte[] d){}
    @Override public void onState(String s){}
    @Override public void onDestroy(){
        if(timeLimitRunnable!=null) timeLimitHandler.removeCallbacks(timeLimitRunnable);
        PairingClient.get().removeListener(this);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){return null;}
}
