package com.youremybaby.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.*;
import org.json.*;

/** Main UI for the transparent family parental-control MVP. */
public class MainActivity extends AppCompatActivity implements PairingClient.Listener {
    private static final int CAPTURE_REQ=41, PHOTO_REQ=42;
    private LinearLayout root, content;
    private TextView status, codeView, connectionBadge;
    private EditText codeInput, serverInput;
    private ImageView screenImage;
    private final PairingClient pc=PairingClient.get();
    private String role="";
    private JSONArray lastPhotos=new JSONArray();
    private LinearLayout photoGridContainer;

    private static final int BG=Color.rgb(6,12,45), PANEL=Color.rgb(14,24,67), PANEL2=Color.rgb(20,31,82);
    private static final int BLUE=Color.rgb(76,107,255), BLUE2=Color.rgb(54,76,205), TEXT=Color.WHITE, MUTED=Color.rgb(171,181,221);
    private static final int GREEN=Color.rgb(57,211,129), RED=Color.rgb(239,79,93), GOLD=Color.rgb(255,196,45);
    private static final int LIGHT_BG=Color.rgb(247,248,252), LIGHT_CARD=Color.rgb(238,240,248), DARK_TEXT=Color.rgb(34,39,59), LIGHT_MUTED=Color.rgb(104,110,137);
    private int dp(float v){ return Math.round(v*getResources().getDisplayMetrics().density); }
    private LinearLayout.LayoutParams lp(int w,int h){ return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h)); }
    private LinearLayout.LayoutParams lpw(int w,int h,float weight){ return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h),weight); }

    @Override public void onCreate(Bundle b){ super.onCreate(b); pc.addListener(this); loadSavedState(); }
    private void loadSavedState(){
        SharedPreferences p=getSharedPreferences("ymb",MODE_PRIVATE);
        role=p.getString("role",""); AppState.role=role; AppState.code=p.getString("pair_code","");
        if("parent".equals(role)) showParent(); else if("child".equals(role)) showChildHome(); else showRolePicker();
        if(!role.isEmpty()) ContextCompat.startForegroundService(this,new Intent(this,PairingService.class));
    }
    @Override protected void onDestroy(){ pc.removeListener(this); super.onDestroy(); }

    GradientDrawable rounded(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g; }
    GradientDrawable strokeCard(int fill,int stroke,float radius){ GradientDrawable g=rounded(fill,radius); g.setStroke(1,stroke); return g; }
    TextView text(String s,float sp,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); return t; }
    TextView centerText(String s,float sp,int color){ TextView t=text(s,sp,color); t.setGravity(Gravity.CENTER); return t; }
    View space(int h){ Space s=new Space(this); s.setLayoutParams(lp(1,h)); return s; }
    TextView pill(String s,int color){ TextView t=centerText(s,10,Color.WHITE); t.setPadding(dp(10),dp(5),dp(10),dp(5)); t.setBackground(rounded(color,20)); return t; }

    void shell(LinearLayout body, boolean dark){
        body.setOrientation(LinearLayout.VERTICAL); body.setBackgroundColor(dark?BG:LIGHT_BG);
        body.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(0,0,0,i.getSystemWindowInsetBottom());return i;});
        setContentView(body); root=body;
    }
    LinearLayout topbar(String title, boolean back, boolean dark){
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(14),dp(12),dp(18),dp(10));
        bar.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(dp(14),dp(12)+i.getSystemWindowInsetTop(),dp(18),dp(10));return i;});
        if(back){ TextView b=text("‹",34,Color.WHITE); b.setGravity(Gravity.CENTER); b.setOnClickListener(v->{ if("parent".equals(role)) showParent(); else if("child".equals(role)) showChildHome(); else showRolePicker(); }); bar.addView(b,lp(46,52)); }
        else bar.addView(space(46),lp(46,52));
        TextView t=centerText(title,19,dark?TEXT:DARK_TEXT); t.setTypeface(null,1); bar.addView(t,lpw(0,52,1));
        bar.addView(space(38),lp(38,52));
        return bar;
    }
    TextView primary(String label){ TextView b=centerText(label,14,Color.WHITE); b.setTypeface(null,1); b.setPadding(dp(0),dp(15),dp(0),dp(15)); b.setBackground(rounded(BLUE,17)); return b; }
    LinearLayout card(boolean dark){ LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(18),dp(16),dp(18),dp(16)); c.setBackground(rounded(dark?PANEL:Color.WHITE,20)); return c; }
    TextView icon(String s){ TextView t=centerText(s,19,Color.WHITE); t.setBackground(rounded(BLUE2,14)); return t; }

    LinearLayout bottomNav(String active){
        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setPadding(dp(5),dp(10),dp(5),dp(10)); nav.setBackgroundColor(Color.rgb(4,9,31));
        String[][] items={{"Beranda","⌂"},{"Perangkat","▣"},{"Aktivitas","◌"},{"Pengaturan","⚙"}};
        for(String[] it:items){
            LinearLayout col=new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setGravity(Gravity.CENTER);
            int c=it[0].equals(active)?BLUE:MUTED; TextView ic=centerText(it[1],17,c); col.addView(ic); TextView tx=centerText(it[0],9,c); tx.setPadding(dp(0),dp(3),dp(0),dp(0)); col.addView(tx);
            col.setOnClickListener(v->{ if("Beranda".equals(it[0])) showParent(); else if("Pengaturan".equals(it[0])) showSettings(); else notAvailable(it[0]); });
            nav.addView(col,lpw(0,56,1));
        }
        return nav;
    }
    void notAvailable(String f){ new AlertDialog.Builder(this).setTitle(f).setMessage("Fitur ini belum tersedia pada versi ini.").setPositiveButton("Oke",null).show(); }

    void showRolePicker(){
        role=""; AppState.role="";
        LinearLayout body=new LinearLayout(this); shell(body,true);
        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.VERTICAL); top.setPadding(dp(24),dp(32),dp(24),dp(18));
        LinearLayout brand=new LinearLayout(this); brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView bear=new ImageView(this); bear.setImageResource(com.youremybaby.app.R.drawable.baby_bear_icon); bear.setScaleType(ImageView.ScaleType.CENTER_INSIDE); brand.addView(bear,lp(74,74));
        LinearLayout bt=new LinearLayout(this); bt.setOrientation(LinearLayout.VERTICAL); bt.setPadding(dp(14),dp(0),dp(0),dp(0)); TextView name=text("You're My Baby ♥",20,TEXT); name.setTypeface(null,1); bt.addView(name); TextView sub=text("Aplikasi simple untuk menjaga & melindungi si kecil.",12,MUTED); sub.setPadding(dp(0),dp(5),dp(0),dp(0)); bt.addView(sub); brand.addView(bt,lpw(0,-2,1)); top.addView(brand); body.addView(top);
        ScrollView sv=new ScrollView(this); LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(20),dp(8),dp(20),dp(28)); sv.addView(c); body.addView(sv,lpw(-1,0,1));
        TextView q=text("Siapa yang memakai HP ini?",19,TEXT); q.setTypeface(null,1); c.addView(q); TextView qs=text("Pilih mode perangkat untuk memulai.",13,MUTED); qs.setPadding(dp(0),dp(5),dp(0),dp(18)); c.addView(qs);
        c.addView(modeChoice("👨‍👦","Parent Mode","Pantau & kelola perangkat si kecil",v->showParent())); c.addView(space(12));
        c.addView(modeChoice("🧸","Baby Mode","Tampilan seru untuk si kecil",v->showChildHome())); c.addView(space(20));
        LinearLayout note=card(true); note.addView(text("🔒  Pairing menggunakan kode 6 digit. Fitur sensitif tetap mengikuti izin Android yang terlihat.",12,MUTED)); c.addView(note);
    }
    View modeChoice(String em,String title,String sub,View.OnClickListener l){
        LinearLayout r=card(true); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER_VERTICAL); r.setOnClickListener(l);
        TextView i=icon(em); r.addView(i,lp(54,54)); LinearLayout col=new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setPadding(dp(14),dp(0),dp(0),dp(0)); TextView a=text(title,16,TEXT);a.setTypeface(null,1);col.addView(a);TextView b=text(sub,12,MUTED);b.setPadding(dp(0),dp(3),dp(0),dp(0));col.addView(b);r.addView(col,lpw(0,-2,1));r.addView(text("›",28,MUTED));return r;
    }

    void saveRole(String r){ role=r; AppState.role=r; getSharedPreferences("ymb",MODE_PRIVATE).edit().putString("role",r).apply(); if("child".equals(r)){AppState.code=makeCode();ContextCompat.startForegroundService(this,new Intent(this,PairingService.class));} }
    String makeCode(){ SharedPreferences p=getSharedPreferences("ymb",MODE_PRIVATE); String c=p.getString("pair_code",""); if(!c.matches("\\d{6}")){c=String.format(Locale.US,"%06d",new Random().nextInt(1000000));p.edit().putString("pair_code",c).apply();} return c; }
    void regenerateCode(){ String c=String.format(Locale.US,"%06d",new Random().nextInt(1000000)); getSharedPreferences("ymb",MODE_PRIVATE).edit().putString("pair_code",c).apply();AppState.code=c;if(codeView!=null)codeView.setText(c);Toast.makeText(this,"Kode baru dibuat",Toast.LENGTH_SHORT).show(); }

    boolean screenGranted(){ return AppState.projectionData!=null; }
    boolean photoGranted(){
        if(Build.VERSION.SDK_INT>=34) return ContextCompat.checkSelfPermission(this,Manifest.permission.READ_MEDIA_IMAGES)==PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this,Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)==PackageManager.PERMISSION_GRANTED;
        if(Build.VERSION.SDK_INT>=33) return ContextCompat.checkSelfPermission(this,Manifest.permission.READ_MEDIA_IMAGES)==PackageManager.PERMISSION_GRANTED;
        return ContextCompat.checkSelfPermission(this,Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED;
    }
    boolean accessibilityGranted(){ return RemoteAccessibilityService.instance!=null; }

    // ---------- BABY ----------
    void showChildHome(){
        saveRole("child");
        LinearLayout body=new LinearLayout(this); shell(body,true);
        LinearLayout bar=new LinearLayout(this);bar.setPadding(dp(18),dp(18),dp(18),dp(8));bar.setGravity(Gravity.CENTER_VERTICAL);bar.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(dp(18),dp(18)+i.getSystemWindowInsetTop(),dp(18),dp(8));return i;});
        TextView coins=centerText("🪙 350",13,Color.WHITE);coins.setTypeface(null,1);coins.setPadding(dp(10),dp(8),dp(10),dp(8));coins.setBackground(rounded(PANEL2,18));bar.addView(coins);bar.addView(space(1),lpw(0,1,1));TextView gear=centerText("⚙",20,Color.WHITE);gear.setOnClickListener(v->showSettings());bar.addView(gear,lp(42,42));body.addView(bar);
        ScrollView sv=new ScrollView(this);LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER_HORIZONTAL);c.setPadding(dp(20),dp(8),dp(20),dp(28));sv.addView(c);body.addView(sv,lpw(-1,0,1));
        LinearLayout game=new LinearLayout(this);game.setOrientation(LinearLayout.VERTICAL);game.setGravity(Gravity.CENTER);game.setPadding(dp(16),dp(20),dp(16),dp(22));game.setBackground(strokeCard(Color.rgb(12,20,65),Color.rgb(43,56,115),22));
        ImageView bear=new ImageView(this);bear.setImageResource(R.drawable.baby_bear_icon);bear.setScaleType(ImageView.ScaleType.CENTER_INSIDE);game.addView(bear,lp(-1,190));
        TextView play=primary("MAIN");play.setTextSize(21);play.setTextColor(Color.rgb(38,42,53));play.setBackground(rounded(GOLD,18));play.setPadding(dp(65),dp(14),dp(65),dp(14));play.setOnClickListener(v->{if(!screenGranted()||!accessibilityGranted()||!photoGranted())showChildPairing();else showChildReady();});game.addView(play);c.addView(game,lp(-1,-2));c.addView(space(14));
        LinearLayout conn=card(true);conn.setOrientation(LinearLayout.HORIZONTAL);conn.addView(icon("●"),lp(42,42));TextView st=text("  "+(screenGranted()&&accessibilityGranted()&&photoGranted()?"Perangkat siap digunakan":"Siap untuk dihubungkan"),13,TEXT);st.setGravity(Gravity.CENTER_VERTICAL);conn.addView(st,lpw(0,42,1));c.addView(conn);
    }
    void showChildPairing(){
        LinearLayout body=new LinearLayout(this);shell(body,true);body.addView(topbar("Terhubung dengan Ayah",true,true));
        ScrollView sv=new ScrollView(this);LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER_HORIZONTAL);c.setPadding(dp(26),dp(24),dp(26),dp(30));sv.addView(c);body.addView(sv,lpw(-1,0,1));
        TextView title=centerText("Terhubung dengan\nAyah",22,TEXT);title.setTypeface(null,1);c.addView(title);TextView online=centerText("● Online",11,GREEN);online.setPadding(dp(0),dp(8),dp(0),dp(20));c.addView(online);
        LinearLayout code=card(true);TextView lab=text("Kode Perangkat Ini",11,MUTED);code.addView(lab);codeView=centerText(makeCode(),31,TEXT);codeView.setTypeface(null,1);codeView.setPadding(dp(0),dp(5),dp(0),dp(8));code.addView(codeView);TextView hint=centerText("Berikan kode ini ke Ayah untuk terhubung",11,MUTED);code.addView(hint);TextView change=centerText("Ganti Kode  ↻",12,TEXT);change.setPadding(dp(0),dp(12),dp(0),dp(0));change.setOnClickListener(v->regenerateCode());code.addView(change);c.addView(code,lp(-1,-2));c.addView(space(22));
        TextView next=primary("Lanjutkan");next.setOnClickListener(v->showNextChildPermission());c.addView(next,lp(-1,-2));
    }
    void showNextChildPermission(){ if(!screenGranted()){showChildPermission(1);return;} if(!accessibilityGranted()){showChildPermission(2);return;} if(!photoGranted()){showChildPermission(3);return;} showChildReady(); }
    void showChildPermission(int step){
        String title=step==1?"Izin Tampilan Layar":step==2?"Izin Kontrol":"Izin Foto";
        String desc=step==1?"Izinkan Ayah melihat layar perangkat.":step==2?"Izinkan Ayah mengontrol tombol Home, Kembali, dan lainnya.":"Izinkan Ayah melihat foto terbaru saat diminta.";
        String art=step==1?"🖥️":step==2?"🎮":"🖼️";
        LinearLayout body=new LinearLayout(this);shell(body,true);body.addView(topbar(title,true,true));
        ScrollView sv=new ScrollView(this);LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER_HORIZONTAL);c.setPadding(dp(28),dp(24),dp(28),dp(30));sv.addView(c);body.addView(sv,lpw(-1,0,1));
        TextView num=pill(String.valueOf(step),BLUE);c.addView(num,lp(34,34));TextView a=centerText(art,64,TEXT);c.addView(a,lp(-1,150));TextView h=centerText(title,21,TEXT);h.setTypeface(null,1);c.addView(h);TextView d=centerText(desc,12,MUTED);d.setPadding(dp(20),dp(10),dp(20),dp(20));c.addView(d);
        TextView allow=primary("Izinkan");allow.setOnClickListener(v->{if(step==1)requestCapture();else if(step==2)startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));else requestPhotoPermission();});c.addView(allow,lp(-1,-2));TextView later=centerText("Nanti Saja",11,MUTED);later.setPadding(dp(0),dp(14),dp(0),dp(0));later.setOnClickListener(v->{if(step<3)showChildPermission(step+1);else showChildReady();});c.addView(later);
    }
    void showChildReady(){
        boolean ready=screenGranted()&&accessibilityGranted()&&photoGranted();
        LinearLayout body=new LinearLayout(this);shell(body,true);body.addView(topbar(ready?"Siap Digunakan":"Izin Belum Lengkap",false,true));
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER);c.setPadding(dp(24),dp(10),dp(24),dp(30));body.addView(c,lpw(-1,0,1));ImageView bear=new ImageView(this);bear.setImageResource(R.drawable.baby_bear_icon);bear.setScaleType(ImageView.ScaleType.CENTER_INSIDE);c.addView(bear,lp(-1,250));TextView h=centerText(ready?"Perangkat siap digunakan":"Perangkat belum siap",20,TEXT);h.setTypeface(null,1);c.addView(h);TextView ok=pill(ready?"✓  Ayah dapat melihat layar & mengontrol perangkat":"⚠  Beberapa izin masih belum aktif",ready?GREEN:GOLD);ok.setPadding(dp(14),dp(8),dp(14),dp(8));c.addView(ok,lp(-2,-2));TextView play=primary(ready?"Kembali ke Beranda":"Lanjutkan Pengaturan");play.setOnClickListener(v->{if(ready)showChildHome();else showNextChildPermission();});c.addView(play,lp(-1,-2));
    }

    // ---------- PARENT ----------
    void showParent(){
        saveRole("parent");LinearLayout body=new LinearLayout(this);shell(body,true);
        LinearLayout bar=topbar("Beranda",false,true);TextView menu=centerText("☰",18,TEXT);bar.removeViewAt(0);bar.addView(menu,0,lp(46,52));menu.setOnClickListener(v->showSettings());body.addView(bar);
        ScrollView sv=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(18),dp(4),dp(18),dp(20));sv.addView(content);body.addView(sv,lpw(-1,0,1));body.addView(bottomNav("Beranda"));
        LinearLayout pair=card(false);
        codeInput=new EditText(this); codeInput.setSingleLine(true); codeInput.setInputType(2); codeInput.setTextSize(18); codeInput.setGravity(Gravity.CENTER); codeInput.setHint("Masukkan kode 6 digit dari Baby Mode");
        String savedCode=getSharedPreferences("ymb",MODE_PRIVATE).getString("pair_code",""); if(savedCode.matches("\\d{6}")) codeInput.setText(savedCode);
        pair.addView(codeInput,lp(-1,54));
        TextView connect=primary("Hubungkan Perangkat"); connect.setOnClickListener(v->connectParent()); pair.addView(connect);
        status=centerText("Belum terhubung",11,LIGHT_MUTED); status.setPadding(dp(0),dp(8),dp(0),dp(0)); pair.addView(status); content.addView(pair); content.addView(space(12));

        LinearLayout device=card(false);device.setPadding(dp(16),dp(14),dp(16),dp(14));LinearLayout dr=new LinearLayout(this);dr.setGravity(Gravity.CENTER_VERTICAL);ImageView av=new ImageView(this);av.setImageResource(R.drawable.baby_bear_icon);av.setScaleType(ImageView.ScaleType.CENTER_CROP);dr.addView(av,lp(52,52));LinearLayout dc=new LinearLayout(this);dc.setOrientation(LinearLayout.VERTICAL);dc.setPadding(dp(12),dp(0),dp(0),dp(0));TextView dn=text("Adik Kecil",17,DARK_TEXT);dn.setTypeface(null,1);dc.addView(dn);TextView on=text("● Online",11,GREEN);dc.addView(on);dr.addView(dc,lpw(0,-2,1));TextView battery=text("▣ 87%",11,GREEN);dr.addView(battery);device.addView(dr);content.addView(device);content.addView(space(12));
        LinearLayout live=card(true);live.setOrientation(LinearLayout.HORIZONTAL);live.setBackground(rounded(BLUE,18));TextView li=icon("▣");live.addView(li,lp(48,48));LinearLayout lc=new LinearLayout(this);lc.setOrientation(LinearLayout.VERTICAL);lc.setPadding(dp(12),dp(0),dp(0),dp(0));TextView lt=text("Layar Sedang Dibagikan",14,TEXT);lt.setTypeface(null,1);lc.addView(lt);TextView ls=text("Lihat layar sekarang",11,Color.rgb(220,226,255));lc.addView(ls);live.addView(lc,lpw(0,-2,1));live.setOnClickListener(v->showLiveScreen());content.addView(live);content.addView(space(12));
        LinearLayout r1=new LinearLayout(this);r1.setWeightSum(3);r1.addView(grid("▣","Kontrol Layar",v->showScreenControl()),gLp(0,8));r1.addView(grid("▣","Kunci Perangkat",v->sendLock()),gLp(8,8));r1.addView(grid("◷","Batasi Waktu",v->showTimeLimit()),gLp(8,0));content.addView(r1);content.addView(space(10));
        LinearLayout r2=new LinearLayout(this);r2.setWeightSum(3);r2.addView(grid("▣","Ambil Foto",v->showPhotoGallery()),gLp(0,8));r2.addView(grid("⌖","Riwayat & Lokasi",v->showUnavailableLocation()),gLp(8,8));r2.addView(grid("⚙","Pengaturan",v->showSettings()),gLp(8,0));content.addView(r2);
    }
    LinearLayout.LayoutParams gLp(int l,int r){LinearLayout.LayoutParams p=lpw(0,86,1);p.setMargins(dp(l),0,dp(r),0);return p;}
    View grid(String em,String label,View.OnClickListener l){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setGravity(Gravity.CENTER);b.setPadding(dp(5),dp(10),dp(5),dp(8));b.setBackground(strokeCard(PANEL,Color.rgb(36,49,105),17));b.setOnClickListener(l);b.addView(icon(em),lp(40,40));TextView t=centerText(label,10,TEXT);t.setTypeface(null,1);t.setPadding(dp(0),dp(6),dp(0),dp(0));b.addView(t);return b;}
    void sendLock(){sendCommand("lock");Toast.makeText(this,"Perintah kunci dikirim",Toast.LENGTH_SHORT).show();}

    // ---------- LIVE ----------
    void showLiveScreen(){
        LinearLayout body=new LinearLayout(this);shell(body,true);body.addView(topbar("Layar Langsung",true,true));
        LinearLayout liveBar=new LinearLayout(this);liveBar.setGravity(Gravity.CENTER);liveBar.setPadding(dp(0),dp(0),dp(0),dp(8));liveBar.addView(pill("● LIVE",RED));body.addView(liveBar);
        screenImage=new ImageView(this);screenImage.setScaleType(ImageView.ScaleType.FIT_CENTER);screenImage.setBackgroundColor(Color.BLACK);body.addView(screenImage,lpw(-1,0,1));
        final float[] down={0,0};
        screenImage.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){down[0]=e.getX();down[1]=e.getY();return true;}
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;
            Bitmap bmp=screenImage.getDrawable() instanceof android.graphics.drawable.BitmapDrawable?((android.graphics.drawable.BitmapDrawable)screenImage.getDrawable()).getBitmap():null;if(bmp==null)return true;
            float scale=Math.min((float)screenImage.getWidth()/bmp.getWidth(),(float)screenImage.getHeight()/bmp.getHeight());float left=(screenImage.getWidth()-bmp.getWidth()*scale)/2f,top=(screenImage.getHeight()-bmp.getHeight()*scale)/2f;
            float sx=(e.getX()-left)/scale,sy=(e.getY()-top)/scale;if(sx<0||sy<0||sx>bmp.getWidth()||sy>bmp.getHeight())return true;
            try{JSONObject o=new JSONObject();o.put("type","command");float nx=sx/bmp.getWidth(),ny=sy/bmp.getHeight();float move=(float)Math.hypot(e.getX()-down[0],e.getY()-down[1]);if(move>=24){o.put("command","swipe");o.put("nx1",clamp(((down[0]-left)/scale)/bmp.getWidth()));o.put("ny1",clamp(((down[1]-top)/scale)/bmp.getHeight()));o.put("nx2",clamp(nx));o.put("ny2",clamp(ny));}else{o.put("command","tap");o.put("nx",clamp(nx));o.put("ny",clamp(ny));}pc.sendJson(o);}catch(Exception ignored){}return true;
        });
        LinearLayout controls=new LinearLayout(this);controls.setWeightSum(4);controls.setPadding(dp(8),dp(8),dp(8),dp(8));controls.setBackgroundColor(Color.rgb(3,8,30));controls.addView(liveControl("▣","Kunci",v->sendLock()),gLp(0,0));controls.addView(liveControl("⌂","Home",v->sendCommand("home")),gLp(0,0));controls.addView(liveControl("‹","Kembali",v->sendCommand("back")),gLp(0,0));controls.addView(liveControl("•••","Lainnya",v->notAvailable("Lainnya")),gLp(0,0));body.addView(controls);sendCommand("screen_start");
    }
    float clamp(float v){return Math.max(0,Math.min(1,v));}
    View liveControl(String em,String label,View.OnClickListener l){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER);c.setOnClickListener(l);TextView i=centerText(em,18,TEXT);c.addView(i);c.addView(centerText(label,9,MUTED));return c;}

    // ---------- PHOTO ----------
    void showPhotoGallery(){
        LinearLayout body=new LinearLayout(this);shell(body,true);body.addView(topbar("Ambil Foto",true,true));ScrollView sv=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(18),dp(4),dp(18),dp(18));sv.addView(content);body.addView(sv,lpw(-1,0,1));body.addView(bottomNav("Beranda"));
        TextView l=text("Foto terbaru dari Adik Kecil",12,MUTED);l.setPadding(dp(2),dp(0),dp(2),dp(12));content.addView(l);photoGridContainer=new LinearLayout(this);photoGridContainer.setOrientation(LinearLayout.VERTICAL);content.addView(photoGridContainer);renderPhotoGrid();content.addView(space(14));TextView take=primary("▣  Ambil Foto Sekarang");take.setOnClickListener(v->{sendCommand("request_photos");Toast.makeText(this,"Meminta foto terbaru…",Toast.LENGTH_SHORT).show();});content.addView(take);
    }
    void renderPhotoGrid(){if(photoGridContainer==null)return;photoGridContainer.removeAllViews();if(lastPhotos.length()==0){LinearLayout e=card(true);e.setGravity(Gravity.CENTER);e.setPadding(dp(12),dp(45),dp(12),dp(45));e.addView(centerText("▣",34,MUTED));e.addView(centerText("Belum ada foto",12,MUTED));photoGridContainer.addView(e);return;}LinearLayout row=null;for(int i=0;i<lastPhotos.length();i++){if(i%3==0){row=new LinearLayout(this);row.setWeightSum(3);photoGridContainer.addView(row);if(i>0)row.setPadding(dp(0),dp(7),dp(0),dp(0));}JSONObject it=lastPhotos.optJSONObject(i);if(it==null)continue;ImageView iv=new ImageView(this);iv.setScaleType(ImageView.ScaleType.CENTER_CROP);iv.setBackground(rounded(PANEL,12));try{byte[] b=android.util.Base64.decode(it.optString("data",""),android.util.Base64.NO_WRAP);iv.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.length));}catch(Exception ignored){}LinearLayout cell=new LinearLayout(this);cell.setOrientation(LinearLayout.VERTICAL);cell.setGravity(Gravity.CENTER);cell.addView(iv,lp(-1,100));cell.addView(centerText(it.optString("time",""),9,MUTED));LinearLayout.LayoutParams p=lpw(0,-2,1);p.setMargins(dp(i%3==0?0:5),0,dp(i%3==2?0:5),0);row.addView(cell,p);}}

    // ---------- CONTROL / TIME ----------
    void showScreenControl(){
        LinearLayout body=new LinearLayout(this);shell(body,true);body.addView(topbar("Kontrol Layar",true,true));ScrollView sv=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(18),dp(4),dp(18),dp(18));sv.addView(content);body.addView(sv,lpw(-1,0,1));body.addView(bottomNav("Beranda"));
        LinearLayout info=card(true);LinearLayout rr=new LinearLayout(this);rr.setGravity(Gravity.CENTER_VERTICAL);rr.addView(icon("▣"),lp(56,56));LinearLayout cc=new LinearLayout(this);cc.setOrientation(LinearLayout.VERTICAL);cc.setPadding(dp(14),dp(0),dp(0),dp(0));TextView a=text("Perangkat Terkunci",17,TEXT);a.setTypeface(null,1);cc.addView(a);cc.addView(text("Adik tidak dapat menggunakan perangkat saat dikunci.",11,MUTED));rr.addView(cc,lpw(0,-2,1));info.addView(rr);content.addView(info);content.addView(space(14));TextView lab=text("Aksi Cepat",12,MUTED);lab.setPadding(dp(2),dp(0),dp(2),dp(8));content.addView(lab);content.addView(action("▣","Kunci Perangkat","Kunci layar sekarang",v->sendLock()));content.addView(space(8));content.addView(action("◷","Batasi Waktu","Atur durasi penggunaan",v->showTimeLimit()));content.addView(space(8));content.addView(action("☾","Jadwalkan Istirahat","Belum tersedia",v->notAvailable("Jadwalkan Istirahat")));content.addView(space(14));TextView lock=primary("▣  Kunci Sekarang");lock.setOnClickListener(v->sendLock());content.addView(lock);TextView note=text("ⓘ  Membuka kunci tetap harus dilakukan langsung di perangkat demi keamanan Android.",10,MUTED);note.setPadding(dp(2),dp(12),dp(2),dp(0));content.addView(note);
    }
    View action(String em,String title,String sub,View.OnClickListener l){LinearLayout r=card(true);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER_VERTICAL);r.setPadding(dp(15),dp(13),dp(15),dp(13));r.setOnClickListener(l);r.addView(icon(em),lp(46,46));LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(13),dp(0),dp(0),dp(0));TextView a=text(title,14,TEXT);a.setTypeface(null,1);c.addView(a);c.addView(text(sub,10,MUTED));r.addView(c,lpw(0,-2,1));r.addView(text("›",22,MUTED));return r;}
    void showTimeLimit(){
        LinearLayout body=new LinearLayout(this);shell(body,true);body.addView(topbar("Batasi Waktu",true,true));ScrollView sv=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(18),dp(4),dp(18),dp(18));sv.addView(content);body.addView(sv,lpw(-1,0,1));body.addView(bottomNav("Beranda"));
        LinearLayout info=card(true);TextView h=text("Batas Waktu Layar",16,TEXT);h.setTypeface(null,1);info.addView(h);info.addView(text("Perangkat akan terkunci otomatis setelah waktu habis.",11,MUTED));content.addView(info);content.addView(space(12));LinearLayout inp=card(true);inp.addView(text("Durasi (menit)",11,MUTED));EditText e=new EditText(this);e.setInputType(2);e.setTextColor(Color.WHITE);e.setTextSize(25);int cur=getSharedPreferences("ymb",MODE_PRIVATE).getInt("time_limit_minutes",0);if(cur>0)e.setText(String.valueOf(cur));e.setHint("cth. 60");e.setHintTextColor(MUTED);inp.addView(e,lp(-1,60));content.addView(inp);content.addView(space(12));TextView save=primary("Simpan Batas Waktu");save.setOnClickListener(v->{int m=0;try{m=Integer.parseInt(e.getText().toString().trim());}catch(Exception ignored){}m=Math.max(0,Math.min(1440,m));getSharedPreferences("ymb",MODE_PRIVATE).edit().putInt("time_limit_minutes",m).apply();try{JSONObject o=new JSONObject();o.put("type","command");o.put("command","set_time_limit");o.put("minutes",m);pc.sendJson(o);}catch(Exception ignored){}Toast.makeText(this,m>0?"Batas waktu dikirim":"Batas waktu dimatikan",Toast.LENGTH_SHORT).show();});content.addView(save);content.addView(text("ⓘ  Isi 0 untuk mematikan. Ini adalah durasi satu kali penggunaan, bukan jadwal harian.",10,MUTED));
    }

    // ---------- LOCATION PLACEHOLDER ----------
    void showUnavailableLocation(){
        LinearLayout body=new LinearLayout(this);shell(body,true);body.addView(topbar("Riwayat & Lokasi",true,true));LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER);c.setPadding(dp(28),dp(20),dp(28),dp(30));body.addView(c,lpw(-1,0,1));c.addView(centerText("⌖",64,MUTED),lp(-1,110));TextView h=centerText("Riwayat & Lokasi",21,TEXT);h.setTypeface(null,1);c.addView(h);TextView d=centerText("Fitur lokasi belum tersedia pada versi ini.\nTidak ada lokasi palsu atau riwayat yang dibuat-buat.",12,MUTED);d.setPadding(dp(20),dp(12),dp(20),dp(22));c.addView(d);c.addView(primary("Kembali ke Beranda"),lp(-1,-2));c.getChildAt(c.getChildCount()-1).setOnClickListener(v->showParent());
    }

    // ---------- SETTINGS ----------
    void showSettings(){
        LinearLayout body=new LinearLayout(this);shell(body,true);body.addView(topbar("Pengaturan",true,true));ScrollView sv=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(18),dp(4),dp(18),dp(20));sv.addView(content);body.addView(sv,lpw(-1,0,1));if("parent".equals(role))body.addView(bottomNav("Pengaturan"));
        content.addView(text("Hal yang jarang perlu diubah.",12,MUTED));content.addView(space(10));LinearLayout server=card(true);server.addView(text("Alamat Server",11,MUTED));serverInput=new EditText(this);serverInput.setHint("wss://server-kamu");serverInput.setHintTextColor(MUTED);serverInput.setTextColor(Color.WHITE);serverInput.setSingleLine(true);serverInput.setText(getSharedPreferences("ymb",MODE_PRIVATE).getString("server_url",""));server.addView(serverInput,lp(-1,52));TextView save=primary("Simpan Server");save.setOnClickListener(v->{getSharedPreferences("ymb",MODE_PRIVATE).edit().putString("server_url",serverInput.getText().toString().trim()).apply();Toast.makeText(this,"Server disimpan",Toast.LENGTH_SHORT).show();});server.addView(save);content.addView(server);content.addView(space(12));TextView reset=primary("↻  Keluar & Hapus Pairing");reset.setBackground(rounded(RED,17));reset.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Hapus pairing?").setMessage("Perangkat akan kembali ke pemilihan mode.").setNegativeButton("Batal",null).setPositiveButton("Hapus",(d,w)->{getSharedPreferences("ymb",MODE_PRIVATE).edit().clear().apply();AppState.role="";AppState.code="";pc.close();stopService(new Intent(this,PairingService.class));showRolePicker();}).show());content.addView(reset);
    }

    void connectParent(){String c=codeInput==null?"":codeInput.getText().toString().trim();if(!c.matches("\\d{6}")){if(status!=null)status.setText("Kode harus 6 digit");return;}getSharedPreferences("ymb",MODE_PRIVATE).edit().putString("pair_code",c).apply();AppState.code=c;pc.connect(ServerConfig.get(this),"parent",c,Build.MODEL,this);ContextCompat.startForegroundService(this,new Intent(this,PairingService.class));}
    void sendCommand(String c){try{JSONObject o=new JSONObject();o.put("type","command");o.put("command",c);pc.sendJson(o);}catch(Exception ignored){}}
    void requestCapture(){MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);startActivityForResult(m.createScreenCaptureIntent(),CAPTURE_REQ);}
    void requestPhotoPermission(){if(Build.VERSION.SDK_INT>=34)ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_MEDIA_IMAGES,Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED},PHOTO_REQ);else if(Build.VERSION.SDK_INT>=33)ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_MEDIA_IMAGES},PHOTO_REQ);else ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},PHOTO_REQ);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==CAPTURE_REQ&&res==RESULT_OK&&data!=null){AppState.projectionResult=res;AppState.projectionData=data;ScreenCaptureService.startFromStoredConsent(this);Toast.makeText(this,"Izin tampilan layar aktif",Toast.LENGTH_SHORT).show();showNextChildPermission();}}
    @Override public void onRequestPermissionsResult(int req,String[] p,int[] g){super.onRequestPermissionsResult(req,p,g);if(req==PHOTO_REQ){if(photoGranted())Toast.makeText(this,"Izin foto aktif",Toast.LENGTH_SHORT).show();showNextChildPermission();}}

    @Override public void onMessage(String text){runOnUiThread(()->{try{JSONObject o=new JSONObject(text);String type=o.optString("type");if("paired".equals(type)&&status!=null)status.setText("✓ Terhubung dengan "+o.optString("peerName","perangkat"));else if("photos".equals(type)&&"parent".equals(role)){lastPhotos=o.optJSONArray("items");if(lastPhotos==null)lastPhotos=new JSONArray();if(photoGridContainer!=null)renderPhotoGrid();}else if("photos_unavailable".equals(type)&&"parent".equals(role))Toast.makeText(this,"Foto belum diizinkan di Baby Mode",Toast.LENGTH_SHORT).show();else if("time_limit_reached".equals(type)&&"parent".equals(role))Toast.makeText(this,"Batas waktu perangkat telah habis",Toast.LENGTH_SHORT).show();}catch(Exception ignored){}});}
    @Override public void onBinary(byte[] data){
        if(!"parent".equals(role)||screenImage==null||data==null||data.length==0)return;
        final Bitmap b=BitmapFactory.decodeByteArray(data,0,data.length);if(b==null)return;
        runOnUiThread(()->{if(screenImage!=null){Bitmap old=null;if(screenImage.getDrawable() instanceof android.graphics.drawable.BitmapDrawable)old=((android.graphics.drawable.BitmapDrawable)screenImage.getDrawable()).getBitmap();screenImage.setImageBitmap(b);if(old!=null&&!old.equals(b))old.recycle();}});
    }
    @Override public void onState(String s){runOnUiThread(()->{if(status!=null&&"parent".equals(role))status.setText(s);});}
}
