package com.youremybaby.app;

import android.content.Intent;

/** In-process state shared by the setup screen and foreground services. */
public final class AppState {
    private AppState() {}
    public static String role = "";
    public static String code = "";
    public static String deviceName = "";
    public static Intent projectionData;
    public static int projectionResult;
}
