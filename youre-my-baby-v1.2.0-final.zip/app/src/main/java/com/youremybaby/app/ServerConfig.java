package com.youremybaby.app;

import android.content.Context;

public final class ServerConfig {
    private ServerConfig() {}
    public static String get(Context c) {
        String saved=c.getSharedPreferences("ymb",Context.MODE_PRIVATE).getString("server_url","").trim();
        if(!saved.isEmpty()) return saved;
        return "wss://YOUR-RELAY-DOMAIN.example";
    }
}
