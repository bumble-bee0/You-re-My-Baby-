package com.youremybaby.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import org.json.JSONObject;

public class RemoteAccessibilityService extends AccessibilityService {
    public static RemoteAccessibilityService instance;
    @Override public void onServiceConnected(){ instance=this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event){}
    @Override public void onInterrupt(){ instance=null; }
    @Override public void onDestroy(){ instance=null; super.onDestroy(); }

    public void handleCommand(JSONObject o){
        try{
            String type=o.optString("command");
            android.util.DisplayMetrics dm=getResources().getDisplayMetrics();
            if("tap".equals(type)){
                float x=o.has("nx")?(float)o.getDouble("nx")*dm.widthPixels:(float)o.getDouble("x");
                float y=o.has("ny")?(float)o.getDouble("ny")*dm.heightPixels:(float)o.getDouble("y");
                tap(Math.max(0,Math.min(dm.widthPixels-1,x)),Math.max(0,Math.min(dm.heightPixels-1,y)));
            } else if("swipe".equals(type)){
                float x1=o.has("nx1")?(float)o.getDouble("nx1")*dm.widthPixels:(float)o.getDouble("x1");
                float y1=o.has("ny1")?(float)o.getDouble("ny1")*dm.heightPixels:(float)o.getDouble("y1");
                float x2=o.has("nx2")?(float)o.getDouble("nx2")*dm.widthPixels:(float)o.getDouble("x2");
                float y2=o.has("ny2")?(float)o.getDouble("ny2")*dm.heightPixels:(float)o.getDouble("y2");
                swipe(Math.max(0,Math.min(dm.widthPixels-1,x1)),Math.max(0,Math.min(dm.heightPixels-1,y1)),Math.max(0,Math.min(dm.widthPixels-1,x2)),Math.max(0,Math.min(dm.heightPixels-1,y2)));
            }
            else if("home".equals(type)) performGlobalAction(GLOBAL_ACTION_HOME);
            else if("back".equals(type)) performGlobalAction(GLOBAL_ACTION_BACK);
            else if("recents".equals(type)) performGlobalAction(GLOBAL_ACTION_RECENTS);
            else if("lock".equals(type) && android.os.Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
        }catch(Exception ignored){}
    }
    public void lockNow(){ if(android.os.Build.VERSION.SDK_INT>=28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN); }
    private void tap(float x,float y){ Path p=new Path(); p.moveTo(x,y); dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,80)).build(),null,null); }
    private void swipe(float x1,float y1,float x2,float y2){ Path p=new Path(); p.moveTo(x1,y1); p.lineTo(x2,y2); dispatchGesture(new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,350)).build(),null,null); }
}
